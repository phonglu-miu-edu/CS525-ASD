package framework.models;

public interface IEntry {
    public void process();
}
