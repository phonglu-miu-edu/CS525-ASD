package framework.models;

public interface ICustomer {
    public void addAccount(Account account);
}
