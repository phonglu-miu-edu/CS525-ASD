package framework.views;

public enum VIEW_TYPE {
    FRAMEWORK,
    CCARD,
    BANK
}
