package framework.commands;

public interface IOperation {
    void execute();
}
