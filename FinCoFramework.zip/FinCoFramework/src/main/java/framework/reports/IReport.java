package framework.reports;

public interface IReport {
    void generateReport();
}
