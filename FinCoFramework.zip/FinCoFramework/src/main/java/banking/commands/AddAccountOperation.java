package banking.commands;

import framework.commands.IOperation;
import framework.IFinco;
import framework.models.Account;
import framework.models.Customer;

public class AddAccountOperation implements IOperation {
    private final Customer customer;
    private Integer type;
    private final IFinco finCo;
    private Account account;
    private String accountNum;

    public AddAccountOperation(Customer customer, String accountNum, Integer type, IFinco finCo) {
        this.customer = customer;
        this.type = type;
        this.finCo = finCo;
        this.accountNum = accountNum;
        this.type = type;
    }

    @Override
    public void execute() {
        account = this.finCo.createAccount(customer, accountNum, type);
    }

    public Account getAccount() {
        return this.account;
    }
}
