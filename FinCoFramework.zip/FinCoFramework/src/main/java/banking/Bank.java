package banking;

import banking.views.BankViewController;
import framework.commands.OperationManager;
import framework.database.IRepository;
import framework.Framework;
import framework.views.IFincoViewController;
import framework.IFinco;
import framework.views.VIEW_TYPE;

public class Bank extends Framework {
    public static void main(String[] args) {
        IFincoViewController viewController = new BankViewController(VIEW_TYPE.BANK);
        IFinco finCoExtension = new FinCoExtension();
        OperationManager operationManager = new OperationManager();
        Bank bank = new Bank();

        Framework.setUp(bank, viewController, finCoExtension, operationManager);
    }

    public void initData() {
        IRepository repo = this.viewController.getFrameworkApplication().getFinCo().getRepository();
        repo.load(repo.getRepoPath());

//        Customer customer1 = this.ui.createPerson(
//                "account01",
//            "Bayarkhuu",
//            "+16418191530",
//            "Street",
//            "Fairfield",
//            52557,
//            "l.bayarkhuu@gmail.com",
//            "1996/07/10"
//        );
//
//        System.out.println(this.ui.getCustomers());
//
//        Collection<Account> all_accounts = this.ui.getAccounts();
//        System.out.println(all_accounts);
//
//        IReportStrategy allAccountsReport = new AllAccountsReport(all_accounts);
//        this.finCo.setReportStrategy(allAccountsReport);
//
//        this.ui.generateReport();
//
//        this.ui.addInterest();
//
////        this.ui.deposit(account1, 1000);
////        this.ui.withdraw(account1, 100);
////        this.ui.withdraw(account1, 200);
//
//        this.ui.generateReport();
    }
}
