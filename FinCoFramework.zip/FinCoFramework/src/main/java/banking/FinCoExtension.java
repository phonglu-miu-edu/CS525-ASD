package banking;

import banking.database.BankRepository;
import banking.factories.BankAccountFactory;
import framework.FinCo;
import framework.models.Account;
import framework.models.Customer;
import framework.models.Email;

public class FinCoExtension extends FinCo {
    public FinCoExtension() {
        super();

        this.repository = new BankRepository(this);
        this.repository.setRepoPath("db.json");
    }

    public Account createAccount(Customer customer, String accountNum, Integer type) {
        Account account = BankAccountFactory.createAccount(customer, accountNum, type);
        account.setNotification(new Email(account.getCustomer().getEmail()));
        this.accounts.add(account);
        customer.addAccount(account);
        return account;
    }
}
