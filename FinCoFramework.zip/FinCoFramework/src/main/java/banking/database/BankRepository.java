package banking.database;

import banking.models.Checking;
import banking.models.Saving;
import framework.database.Repository;
import framework.IFinco;
import framework.models.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class BankRepository extends Repository {
	public BankRepository(IFinco finco) {
		super(finco);
	}

	@Override
	public void loadAccount(Customer customer, JSONArray jsonArray) {
		if (jsonArray == null)
			return;

		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject o = (JSONObject) jsonArray.get(i);
			Account a;

			if (o.get("accType") == null) {
				a = new Account(customer, (String) o.get("accountNum"));
			} else if (o.get("accType").equals("checking")) {
				a = new Checking(customer, (String) o.get("accountNum"));
			} else {
				a = new Saving(customer, (String) o.get("accountNum"));
			}
			a.setCurrentBalance(Double.parseDouble(o.get("currentBalance").toString()));

			loadEntry(a, (JSONArray) o.get("entries"));
			a.setNotification(new Email(customer.getEmail()));
			customer.addAccount(a);
			this.finco.getAccounts().add(a);
		}
	}

	@Override
	public void write(String path) {
		JSONObject jsonObject = new JSONObject();
		JSONArray customers = new JSONArray();

		System.out.println(this.finco.getCustomers());

		for (Customer customer : this.finco.getCustomers()) {
			JSONObject c = new JSONObject();
			JSONArray accs = new JSONArray();

			c.put("name", customer.getName());
			c.put("city", customer.getCity());
			c.put("email", customer.getEmail());
			c.put("state", customer.getState());
			c.put("street", customer.getStreet());
			c.put("zip", customer.getZip());

			if (customer.getClass().equals(Company.class))
				c.put("type", "company");
			else if (customer.getClass().equals(Person.class))
				c.put("type", "person");

			System.out.println(customer.getAccounts());

			for (Account account : customer.getAccounts()) {
				JSONObject a = new JSONObject();
				JSONArray entries = new JSONArray();

				a.put("accountNum", account.getAccountNum());
				a.put("currentBalance", account.getCurrentBalance());

				if (account instanceof Checking) {
					a.put("accType", "checking");
				} else if (account instanceof Saving) {
					a.put("accType", "saving");
				}

				for (Entry entry : account.getEntryHistory()) {
					JSONObject e = new JSONObject();

					e.put("amount", entry.getAmount());
					e.put("date", entry.getDate().toString());
					if (entry instanceof DepositEntry) {
						e.put("type", "deposit");
					} else {
						e.put("type", "withdraw");
					}

					entries.add(e);
				}

				a.put("entries", entries);
				accs.add(a);
			}

			c.put("accounts", accs);
			customers.add(c);
		}

		jsonObject.put("customers", customers);

		this.write(path, jsonObject);
	}
}
