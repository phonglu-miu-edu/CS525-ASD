# FinCo Framework

## Plug points
These are the classes that clients should extend or implement in order to use this framework.

### Framework
Framework is the top-most class which wires all the required objects in the system to the framework. It implements IFramework and provides an implementation for the getters and setters of the required objects. It defines a static method called setup() which calls and wires up all the required objects. It also calls the setVisible() method to show a view in case it exists. Clients of the framework have to extend this class, and then call the static setUp() method in their main methods. In doing this, clients inject in their specific versions of the required objects in the system. Such objects are Controllers, Views, FinCo Extensions or Operation Managers. Their details are discussed below.

### FinCoView
FinCoView is the default JFrame view (UI) for the framework. It provides the commonly used functionalities and their implementations. It can be extended by the clients and its methods for handling UI actions can be overridden and modified. The UI elements can also be overridden and modified as necessary. It makes use of a dependency injection of IFincoViewController and uses its methods to act on and display the data stored in the system.

### IFinCoViewController
IFinCoViewController is the interface for the controllers used by FinCoView or its subclasses. It defines methods that carry out the work needed by actions on the views. Among others, it writes and reads the data used by the framework. This helps to separates the business logic and the models from the view. Clients can implement this interface to provide their own implementations of the methods defined by the interface. The framework provides the default controller which is FinCoViewController.

### FinCoViewController
FinCoViewController is the default implementation of IFinCoViewController. It defines the default implementation for required operations such creating a customer, generating reports or withdrawing from an account. It also defines a method setVisible() which creates the current view and makes it visible. Clients can extend this class and add more features or override some methods to change the behavior of their view controllers. It prevents clients from rewriting most of the implementations that are similar.

### IFinco
IFinco defines an interface with all the methods for implementing all the functionality of the framework. It is meant to be the controller and executor of the tasks of the framework. Its implementers should know how to interact with the views and how to do the tasks the views hands over to them. The implementers should know where to save and retrieve the data of the system.

### FinCo
FinCo is the default implementation of IFinco. It knows how to create accounts and customers, how to do withdraws, deposits, and how to add interest and generate reports. It is the receiver of the commands that come from the user interface. After creating the data, it knows how to store it and how to retrieve it when needed. Client apps can extend FinCo to provide extra operations not supported or to override existing methods.

### IOperation
IOperation defines the interface for creating commands that link the user interface objects with the concrete implementation of IFinco. The operation commands created are run by one invoker called the OperationManager, which just runs the execute() method on the commands.

### Account
Clients can extend the Account class to add new types of accounts or override its methods to change behavior or add more features to their accounts.

### Customer
Clients can extend the Customer class to add new types of or to add more features or change its behavior for their specific needs. Person and Company classes are provided in the interface as default extensions of Customer.


## Framework Patterns
These are the design patterns that were used in the development of this framework

### Party Pattern
Bank has two customer types: Person & Company and so we used party pattern for ICustomer, abstract Customer, Person & Company. This pattern helps us to refer to all customers with a similar type but give us the liberty to specialize the operations and properties of the two types of customers. Client applications just have to implement the top ICustomer interface to create a customer.


### Account Pattern
For our account & entries we use account pattern with IAccount, Account, Entry and its concrete subclasses; WithdrawEntry & DepositEntry. Client classes can extend from Account, like how the credit card app creates the CreditCardAccount, and this helps it provide a card type and different rules about interest rates. The framework still treats it as an Account. Other clients who have a very different account format can directly implement IAccount, and that would still work.


### Strategy Pattern
To generate reports for accounts, we use strategy pattern to provide a way for clients to define their own reporting strategy and specific implementation logic, to create different kinds of reports, e.g. the frameworks uses AllAccountsReport by default, then the credit card app adds MonthlyBillingReport. FinCo is the context which sets the report strategy to use. Client apps are expected to set this before running reports, or they will use the default one provided by the framework.


### Command Pattern
To process operations from UI, we use the command pattern. OperationManager class is the invoker, with the IOperation interface the one that defines the interface that other commands inherit from, and then we have concrete commands such as AddPersonOperation, AddCompanyOperation, AddAccountOperation, AddInterestOperation, DepositOperation, WithdrawOperation and GenerateReportOperation, and many others that the clients may add. Each of these commands call FinCo as their receiver of their commands. Command pattern helps provide an avenue to support more UI buttons and also a way to vary the handling of these actions by the clients, when they subclass FinCo and provide specific implementations to their needs. This also allows us to decouple the user interface from the implementation logic.


### Simple Factory Pattern
We use the Simple Factory Pattern to wrap the creation of accounts and customers in public static methods. This helps us to conveniently reuse this code.


### Role Pattern
We use the role pattern to provide distinctive behavior to credit card accounts. This is used by providing a type property to a credit card account, where the type is of type CreditCardType. This can be extended by classes such as Copper, Gold and Silver and each provides specific properties about its interest rates and minimum payment options. The creator of a credit card determines which instance of CreditCardType to associate the credit card with. This pattern allows us to easily change the type associated with a card easily at runtime. Composition here works better because a credit card has a type which might change, but a credit card type is not a credit card, as using inheritance would imply.
 

## Extras
There is persistence for the added items by writing them to JSON files. The application then reads the JSON files to get 
the details of the accounts and customers have already been added.
